#!/usr/bin/python

import numpy as np
import csv
from xml.etree import ElementTree as et

filedir = '/home/joao/usn-data/energy2d-simulation/'
xml_filename = filedir + 'custom_reynolds.e2d'
csv_filename = filedir + 'energy2d-output-data.csv'
F = open(xml_filename, mode='rw')

tree = et.parse(F)
model = tree.find('model')
sensor = model.find('sensor')
thermometers = sensor.findall('thermometer')

for t in thermometers:
    sensor.remove(t)

y_min = 2.7
y_max = 4.6
x_min = 2
x_max = 4

x_s_count = 21
y_s_count = 21

for y_cord in np.linspace(y_max, y_min, y_s_count):
    for x_cord in np.linspace(x_min, x_max, x_s_count):
        e = et.Element('thermometer', {'x':str(x_cord), 'y':str(y_cord)})
        e.tail = '\n'
        sensor.append(e)

tree.write(xml_filename)
F.close()

in_data = np.array(list(csv.reader(open(csv_filename, "rb"), delimiter='\t')))

out_data = np.zeros([x_s_count, y_s_count])
out_data_all = []
out_data_time = []
i = 0
j = 0

for line in in_data:
    for iterator, e in enumerate(line):
        if iterator == 0:
            out_data_time.append(e)
            continue
        out_data[j][i] = e
        i+=1
        if i >= x_s_count:
            i = 0
            j+=1

    out_data_all.append(out_data)
    i=0
    j=0



print out_data_all