#from pprint import pprint

__author__ = 'Joao Loureiro'

#import sys
#import pylab
import csv
import numpy as np
import matplotlib.pyplot as plt
#import re

dir = '/home/joao/usn-data/out/'

def main():
    
    filename = dir + "events-announced-count-m.csv"
#    i=0;
#    j=0;
#    data = [[]]
#    with open(filename, 'rb') as csvfile:
#        my_file = csv.reader(csvfile, delimiter=',')
#        for row in my_file:
#            print row
#
#        i += 1


    reader = csv.reader(open(filename, "rb"),delimiter=',')
    x=list(reader)
    result = np.array(x).astype('int')
#    result = np.array
#    print result
    
    
    """
    Demo of spines offset from the axes (a.k.a. "dropped spines").
    """
 
    fig, ax = plt.subplots()

#    image = np.random.uniform(size=(10, 10))
    image = result;
    ax.imshow(image, cmap = plt.cm.gray, interpolation='nearest')
    ax.set_title('dropped spines')
    

    # Move left and bottom spines outward by 10 points
    ax.spines['left'].set_position(('outward', 10))
    ax.spines['bottom'].set_position(('outward', 10))
    # Hide the right and top spines
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    # Only show ticks on the left and bottom spines
    ax.yaxis.set_ticks_position('left')
    ax.xaxis.set_ticks_position('bottom')

    plt.show()

    # pprint(data)



if __name__ == '__main__':
    main()