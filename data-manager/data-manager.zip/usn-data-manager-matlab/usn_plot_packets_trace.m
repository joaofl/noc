function usn_plot_packets_trace()
    %close all;
    clear;

    path = '~/usn-data/out/';
    cd(path);

    files = dir('*trace.csv');
    s = size(files,1);
    i=1;
    if (s > 1)
        while (i < s)
            name = strcat(path, files(i).name);
            plot(name);
            i= i + 1;
        end

    else
        name = strcat(path, files.name);
        plot(name);
    end
end

function plot(file_name)
    figure;
    data = csvread(file_name);
    
    know_flows = [];
    delta = [];
    
    sink_x = 51;
    sink_y = 51;
    
    size_x = 101;
    size_y = 101;
    
    output_data = zeros(101, 101);
    
    s = size(data,1);
    i = 1;
    j = 1;
    tf = 0;
    while (i <= s)
        fr = data(i,2); % flow reference
        if(ismember(fr, know_flows) == 0)
            j = i;
            know_flows = [know_flows, fr];
            ti = data(i,1); %initial time
            while (j <= s)
                if (data(j,2) == fr && data(j,1) > tf)
                    tf = data(j,1);
                    origin_x = data(j,7);
                    origin_y = data(j,8);
                end
                j=j+1;
            end
            delta = [delta, tf - ti];
            x = size_x - (origin_x + sink_x - 1);
            y = size_y - (origin_y + sink_y - 1);
            output_data(x, y) = (tf - ti)*10E-6;
            tf = 0;
        end
        i=i+1;
    end
    
    know_flows
    delta
    
    
    
    colormap jet
    imagesc(output_data);
    %     contourf(data);
    title(file_name);
    colorbar;

end




