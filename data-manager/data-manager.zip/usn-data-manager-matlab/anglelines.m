pts = 100*rand(3,2);

x=pts(:,1);
y=pts(:,2);
x(1)=0;
y(1)=0;
x(3)=x(2)*0.8*rand(1,1);

x = round(x);
y = round(y);

x = [-4,0,4]';
y = [63102,65530,62786]';

x=x-x(1);
y=y-y(1);


[x y]
close all
plot(x(1),y(1),'xr','LineWidth',3)
hold on
plot(x(2),y(2),'ob','LineWidth',3)
plot(x(3),y(3),'Ok', 'LineWidth',3)


dist12 = sqrt( (x(2)-x(1))^2 + (y(2)-y(1))^2);
dist13 = sqrt( (x(3)-x(1))^2 + (y(3)-y(1))^2);

alpha = acos( (((x(2)-x(1))*(x(3)-x(1)) + (y(2)-y(1))*(y(3)-y(1)))/(dist12*dist13)))

alpha2 = acos( (x(2)*x(3) + y(2)*y(3))/(sqrt( x(2)*x(2)+y(2)*y(2)) *sqrt(x(3)*x(3)+y(3)*y(3))) )


if (y(3)<y(2))
    alpha1 = atan(y(2)/x(2)) - atan(y(3)/x(3));
else
    alpha1 = atan(y(3)/x(3)) - atan(y(2)/x(2));
end
alpha1

h = dist12 * sin(alpha)