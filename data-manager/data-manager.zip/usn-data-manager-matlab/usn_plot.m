function usn_plot()
close all;
clear;

path = '~/usn-data/out/';
%cd(path);

files = dir(strcat(path, '*m.csv'));

i=1;
while (i < size(files,1))
    name = strcat(path, files(i).name);
    plot(name);
    i= i + 1;
end


end

function plot(file_name)
    figure;
    data = csvread(file_name);
    colormap jet
    imagesc(data);
%     contourf(data);
    title(file_name);
    colorbar;

end




