function [ ] = usn_data_generator( )
% USN_DATA_GENERATOR Summary of this function goes here
%   Detailed explanation goes here
clear;

dir = '~/usn-data/in/';

bits = 16;

a = 2^bits-1; %the sensor full scale wich is can be up to 32 bits

x_size = 101;
y_size = 101;

offset = 30;

aux = 0+offset:1:x_size-1+offset;
x = sin(0.027 * aux);
% y = ones(1,y_size)';
% y = y * 0.5 * rand;
% y =  rand(1,101)';
y = sin(0.027 * aux )';

data = y*x;
% data = abs(data');
% data = a.*data;
data = (a/2 .*data + a/2 )';
% data = (data);


figure;
colormap gray
contourf(data);
figure;
colormap gray
imagesc(data);
figure;
colormap gray
surf(data);
csvwrite(strcat(dir, 'input-data.csv'), data);

end

