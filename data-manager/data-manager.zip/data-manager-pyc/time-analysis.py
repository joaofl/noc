__author__ = 'joao'

import csv
import numpy as np
import matplotlib
# matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.animation as animation

###############################################
# Addresses

dir = "/home/joao/usn-data/out/"
video_ext = ".mp4"
text_ext = ".csv"

#fn - file name
fn_pck_trace = dir + "packets-trace" + text_ext
fn_pck_trace_sink = dir + "packets-sink-trace" + text_ext
fn_data_input = dir + "../in/input-data" + text_ext

output_filename = dir + "usn-time-simulation" + video_ext
###############################################
# Var Init

size_x = 101
size_y = 101
max_packets = 100

t_unit = int(1E9)

t_initial = int(2 * t_unit)
t_final = int(10 * t_unit) # in seconds ??
t_step = int(.005 * t_unit)
t_simulation_start = 3 * t_unit
t_time_window = .5 * t_unit

input_data = []
input_data_single_frame = []
input_data_time = []
flows_known = []
################################################


#################### Reading the trace and data files ###################
pck_trace = np.array(list(csv.reader(open(fn_pck_trace, "rb"), delimiter=',')))
pck_trace_sink = np.array(list(csv.reader(open(fn_pck_trace_sink, "rb"), delimiter=',')))

i=0
j=0
k=0

for line in open(fn_data_input):
    if line.startswith('@'):
        j += 1
        # i = 0
        input_data_time.append(int(line.replace('@', '')))
        input_data.append(zip(*np.array(input_data_single_frame)))
        input_data_single_frame = []
    else:
        input_data_single_frame.append(np.array(line.strip().split(',')).astype('int'))

#################### setup the initial plots ####################
data = np.zeros( (size_x, size_y) ) #for initialization only

data1 = np.zeros( (size_x, size_y) ) #the correspondent data of each subplot
data2 = np.zeros( (size_x, size_y) )
data3 = np.zeros( (size_x, size_y) )
data4 = np.zeros( (size_x, size_y) )

data1 = input_data[0]
data2[50,50] = 5

max = np.max(data1)
mean = max / 2
data3 = np.ones( (size_x, size_y) ) * mean
data3[50,50] = max
data3[51,51] = 0

data[50, 50] = 100 # this helps to set the plot ranges, which are automaticaly set at the first plot.
#TODO: replace it to 'set range' functions instead
f = plt.figure()

### 1
ax1 = f.add_subplot(2,2,1)
ax1.axes.get_xaxis().set_visible(False)
ax1.axes.get_yaxis().set_visible(True)
img1 = plt.imshow(data1)
ax1.set_title('Input Data')

### 2
ax2 = f.add_subplot(2,2,2)
ax2.axes.get_xaxis().set_visible(False)
ax2.axes.get_yaxis().set_visible(False)
img2 = plt.imshow(data2)
ax2.set_title('Events Detected')

## 3
ax3 = f.add_subplot(2,2,3)
ax3.axes.get_xaxis().set_visible(True)
ax3.axes.get_yaxis().set_visible(True)
img3 = plt.imshow(data3)
ax3.set_title('Reconstructed Data')

## 4
ax4 = f.add_subplot(2,2,4)
ax4.axes.get_xaxis().set_visible(True)
ax4.axes.get_yaxis().set_visible(False)
img4 = plt.imshow(data)
ax4.set_title('Transmission Done')

i=0
j=0
k=0
################################################################

################## function called to animate the plots ########
def animate(t):
    global data1, data2, data3, data4
    global i,j, k


    ## traces for all the packets
    pck_trace_line = pck_trace[i]
    t_instant = int(pck_trace_line[1])
    flow_id = int(pck_trace_line[2])
    cord_x = int(pck_trace_line[4])
    cord_y = int(pck_trace_line[5])

    ## trances for the sink only
    pck_trace_line_sink = pck_trace_sink[k]
    t_instant_sink = int(pck_trace_line_sink[1])
    flow_id_sink = int(pck_trace_line_sink[2])
    pck_value = int(pck_trace_line_sink[10])
    cord_x_sink = int(pck_trace_line_sink[11])
    cord_y_sink = int(pck_trace_line_sink[12])


    # in this loop, it will process all the data that have occurred until the current time instant t
    # for all of the data logs. Input data will change, also all the packets transmitted/received until that
    while t_instant < t:

        if flow_id not in flows_known:
            flows_known.append(flow_id)
            data2[cord_x, cord_y] += 1

        data4[cord_x, cord_y] += 1

        #get data from the next time instant to check if it has occurred already or not
        i = i+1
        pck_trace_line = pck_trace[i]
        t_instant = int(pck_trace_line[1])
        flow_id = int(pck_trace_line[2])
        cord_x = int(pck_trace_line[4])
        cord_y = int(pck_trace_line[5])

        # plot the input data moving along the time
        if t_instant > input_data_time[j] + t_simulation_start:
            j += 1
            data1 = input_data[j]

        # plot the data reconstruction along the time
        if t_instant_sink < t_instant:
            k += 1
            x = size_x - np.floor(cord_x_sink + size_x / 2) - 1
            y = size_y - np.floor(cord_y_sink + size_y / 2) - 1
            data3[x, y] = pck_value

            if k > 0:
                pck_trace_line_sink_previous = pck_trace_sink[k-2]
                t_instant_sink_previous = int(pck_trace_line_sink_previous[1])

            if t_instant_sink - t_instant_sink_previous > t_time_window:
                data3 = np.ones( (size_x, size_y) ) * mean # reset the values know by the sink if they are too old

            pck_trace_line_sink = pck_trace_sink[k]
            t_instant_sink = int(pck_trace_line_sink[1])
            flow_id_sink = int(pck_trace_line_sink[2])
            pck_value = int(pck_trace_line_sink[10])
            cord_x_sink = int(pck_trace_line_sink[11])
            cord_y_sink = int(pck_trace_line_sink[12])


    # transfer the new data to its respective subplot
    img1.set_array(data1)
    img2.set_array(data2)
    img3.set_array(data3)
    img4.set_array(data4)
    return img1, img2, img3, img4


# plots the data with animation
ani = animation.FuncAnimation(f, animate, np.arange(t_initial, t_final, t_step), interval=15, blit=True, repeat=False)

plt.show()


print "end"