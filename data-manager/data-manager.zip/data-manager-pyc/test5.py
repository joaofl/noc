import matplotlib.pyplot as plt 
import matplotlib.animation as animation 
import sys 
import time 
import re 

x_data   = []         # x 
y_data   = []         # y 

fig   = plt.figure() 
ax    = fig.add_subplot(111) 
curve,= ax.plot([],[],lw=2) 
ax.set_xlim(0,5) 
ax.set_ylim(0,25) 
ax.grid() 

def tail_f(file): 
  while True: 
    where = file.tell()      # current file position, an integer (may be a long integer).
    line = file.readline() 
    if re.search('without errors',line): break 
    # Always yield the line so that we return back to the event loop. If we 
    # need to go back and read again, we'll get a free delay from the 
    # animation system. 
    yield line 
    if not line: 
      file.seek(where)       # seek(offset[, whence]) ->None.  Move to new file position.


def run(line, curve, x, y): 
        if re.search('x=',line): 
            liste = line.split('=') 
            x.append(liste[1].strip()) 
        if re.search('y=',line): 
            liste = line.split('=') 
            y.append(liste[1].strip()) 

            curve.set_data(x,y) 
            print x,y 
        return curve 

# The passed in frames can be a func that returns a generator. This 
# generator keeps return "frame data" 
def data_source(fname=sys.argv[1]): 
        return tail_f(open(fname)) 

# This init function initializes for drawing returns any initialized 
# artists. 
def init(): 
        curve.set_data([],[]) 
        return curve 

line_ani = animation.FuncAnimation(fig, run, data_source, init_func=init, 
        fargs=(curve,x_data,y_data), interval=100) 

plt.show() 