#!/usr/bin/env python
"""
An animated image
"""
import numpy as np
from numpy.lib.npyio import savetxt
import matplotlib.pyplot as plt
import matplotlib.animation as animation

file_dir = "/home/joao/usn-data/in/"
file_name = "input-data"
file_extension = ".csv"

fig = plt.figure()

size_x = 101
size_y = 101
time_step = 1E9 #ns

bits = 16;
sensor_resolution = pow(2, bits);

def f(x, y):
    return ( np.sin(x) * np.cos(y) ) * sensor_resolution / 2 + sensor_resolution / 2; #offset to between 0 and max

x = np.linspace(0, 2 * np.pi, size_x)
y = np.linspace(0, 2 * np.pi, size_y).reshape(-1, 1)

ims = []
data = []

with file(file_dir + file_name + file_extension, 'w') as output_data:
    i = 0
    for i in range(30):
        x += np.pi / 30. ## the steps in x and y
        y += np.pi / 30.

        im = plt.imshow(f(x, y))
        ims.append([im])

        d = f(x,y)
        savetxt(output_data, d, delimiter=',' , fmt='%d')
        # output_data.write('#' + str(i) + '@' + '\n') # metadata goes at after the data, as it is easier to read
        output_data.write('@' + str(i * int(time_step)) + '\n') # starts with # and ends at @
        # print(np.max(d))
        # print(np.min(d))

        i += 1

ani = animation.ArtistAnimation(fig, ims, interval=100, blit=True, repeat_delay=0)
plt.colorbar()

# ani.save('data.mp4') need ffmpeg

plt.show()