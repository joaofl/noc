__author__ = 'joao'

import csv
import numpy
import matplotlib.pylab as p
from os import listdir
import matplotlib.animation as animation
import fileinput

dir_out = "/home/joao/usn-data/out/"
dir_in = "/home/joao/usn-data/in/"
files_list = listdir(dir_out)

###############################################
# Var Init

size_x = 101
size_y = 101
max_packets = 5

t_unit = int(1E9)
t_initial = int(2 * t_unit)
t_final = int(10 * t_unit) # in seconds ??
t_step = int(.005 * t_unit)

################################################


while(1):

    i = 0
    for f in files_list:
        print str(i) + '\t' + f
        i += 1

    try:
        tmp = raw_input('\nFile to plot: (''e'' to exit): ')
        # tmp = 12 #for debuging on7ly
        index = int(tmp)
    except ValueError:
        if tmp == 'e':
            exit(1)

        print "\nInvalid option!\n"
        continue

    # for f in files_list:

    f = files_list[index]

    if f.endswith('m.csv'):
        filename = dir_out + f
        reader = csv.reader(open(filename, "rb"), delimiter=',')
        # x = list(reader)
        result = numpy.array( list(reader) ).astype('int')

        # p.matshow(numpy.log10(result + 1), cmap=p.cm.jet, )
        p.matshow(result, cmap=p.cm.jet, )
        p.colorbar()
        p.grid(False)

        # p.xlabel('Model complexity --->')
        # p.ylabel('Message length --->')

        p.title(f)
        p.show(block=True)

    elif f.endswith('trace.csv'):
        filename = dir_out + f
        filename_in = dir_in + "input-data.csv"
        reader1 = csv.reader(open(filename, "rb"), delimiter=',')


        fig = p.figure()
        ax1 = fig.add_subplot(1, 3, 1)

        result = numpy.array( list(reader1) ) #.astype('int')
        # result2 = numpy.array( list(reader2) )

        output1 = numpy.zeros( (size_x, size_y) )
        output2 = numpy.zeros( (size_x, size_y) )


        mat_arr = []
        mat = []
        arr_time = []
        # ll = [1]

        i=0
        j=0
        # reader2 = open(filename_in, "rb")
        # for line in reader2.xreadlines():
        #     if line == '@':
        #         j+=1
        #     else:
        #         temp[j].append(numpy.array(line))

        for line in open(filename_in):
            if line.startswith('@'):
                j += 1
                # i = 0
                arr_time.append(int(line.replace('@', '')))
                mat_arr.append(zip(*numpy.array(mat)))
                mat = []
            else:

                # s_out = [s.strip('\n') for s in line]
                # ll = numpy.array(list(line)).astype("int")
                mat.append(numpy.array(line.strip().split(',')).astype('int'))
                # temp[j] = numpy.vstack(tt)
                # i+=1

        output1[numpy.floor(size_x / 2), numpy.floor(size_y / 2)] = max_packets # just a reference point in the sink, and the base scale# for the plot
        im1 = p.imshow(output1, cmap=p.get_cmap('jet'))
        # p.colorbar()

        output2[numpy.floor(size_x / 2), numpy.floor(size_y / 2)] = max_packets
        ax2 = fig.add_subplot(1, 3, 2)
        im2 = p.imshow(output2, cmap=p.get_cmap('jet'))
        # p.colorbar()

        output3 = mat_arr[0]
        ax3 = fig.add_subplot(1, 3, 3)
        im3 = p.imshow(output3, cmap=p.get_cmap('jet'))


        global i
        i=0
        j=0
        pck_known = []

        def updatefig(t):
            global i
            print t
            for j in range(20):
                if i < numpy.size(result, 0):
                    line = result[i]
                    n_x = int(line[4])
                    n_y = int(line[5])
                    # time = line[0]

                    present = False

                    if len(pck_known) == 0:
                        pck_known.append(int(line[2]))
                        present = True
                        output1[n_x, n_y] += 1

                    for pck in pck_known:
                        if int(line[2]) == int(pck):
                            present = True
                            break

                    if present == False:
                        pck_known.append(line[2])
                        output1[n_x, n_y] += 1

                    # p.title( line[1] * 10-9 )
                    # ax.annotate('annotate', xy=(2, 1), xytext=(3, 4)
                    i += 1
                j += 1
            im1.set_array(output1)
            # p.matshow(output, cmap=p.cm.jet)
            # p.show()
            # return 0
            return im1,

        flows_known = []

        def updatefig2(t):
            global i,j
            global output3

            line = result[i]
            n_x = int(line[4])
            n_y = int(line[5])
            time = int(line[1])
            flow_id = int(line[2])

            while time < t:

                if flow_id not in flows_known:
                    flows_known.append(flow_id)
                    output2[n_x, n_y] += 1

                output1[n_x, n_y] += 1 # count all the transmissions, even belonging to the same flow

                i+=1
                line = result[i]
                n_x = int(line[4])
                n_y = int(line[5])
                time = int(line[1]) #ns
                flow_id = int(line[2])

                if time > arr_time[j] + 3000000000:
                    j += 1
                    output3 = mat_arr[j]


            im1.set_array(output2)
            im2.set_array(output1)
            im3.set_array(output3)
            return im1,im2,im3

        ani = animation.FuncAnimation(fig, updatefig2, numpy.arange(t_initial, t_final, t_step), interval=10, blit=True, repeat=False)

        # ani.save( dir_out + 'im.mp4', metadata={'artist':'Joao Loureiro'})

        p.show()

        exit(0)
        # p.grid()
        # p.colorbar()

        # p.matshow(output, cmap=p.cm.jet)
        # for line in result:
        #     updatefig()


            # p.grid(False)
            # # p.xlabel('Model complexity --->')
            # # p.ylabel('Message length --->')
            # p.colorbar()
            # # ani.save('data.mp4') need ffmpeg
            # p.show(block=True)