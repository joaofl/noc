
import numpy as np
import matplotlib.pyplot as plt
# from matplotlib.lines import Line2D
import matplotlib.animation as animation











filename = dir + f
reader = csv.reader(open(filename, "rb"), delimiter=',')




fig = plt.figure()
ax1 = fig.add_subplot(2, 2, 1)
ax2 = fig.add_subplot(2, 2, 2)
ax3 = fig.add_subplot(2, 2, 3)
ax4 = fig.add_subplot(2, 2, 4)

plt.show()