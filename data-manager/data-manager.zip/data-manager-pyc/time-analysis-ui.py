__author__ = 'joao'

import csv
import sys
import os
import numpy as np
import matplotlib
# matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from numpy.lib.npyio import savetxt

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic, QtGui

import os
import shlex
from subprocess import Popen, PIPE

import matplotlib
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QTAgg as NavigationToolbar
from matplotlib.figure import Figure

i = 0
j = 0
k = 0

form_class = uic.loadUiType("time-analysis-ui.ui")[0]                 # Load the UI

class MyWindowClass(QtGui.QWidget, form_class):
    def __init__(self, parent=None):
        QtGui.QMainWindow.__init__(self, parent)
        self.setWindowTitle('uSN Time Analysis Tool')
        self.setupUi(self)

        self.pbStart.clicked.connect(self.pbStart_clicked)
        self.pbStop.clicked.connect(self.pbStop_clicked)
        self.pbGenerate.clicked.connect(self.pbGenerate_clicked)
        self.pbSelectWorkingDir.clicked.connect(self.pbSelectWorkingDir_clicked)
        self.pbSelectNs3Dir.clicked.connect(self.pbSelectNs3Dir_clicked)
        self.pbRunSimulation.clicked.connect(self.pbRunSimulation_clicked)

        self.timer_gd = QTimer(self)
        QObject.connect(self.timer_gd, SIGNAL("timeout()"), self.animate_gd)

        self.timer_ta = QTimer(self)
        QObject.connect(self.timer_ta, SIGNAL("timeout()"), self.update_plot)

        self.create_frames()
        # self.read_files()
        # self.initial_plot_setup()

    def create_frames(self):
        # setup the plot area space for the time analysis
        self.frame_ta = self.wgPlot
        self.fig_ta = Figure() #Figure((5.0, 4.0), dpi=100)
        self.canvas_ta = FigureCanvas(self.fig_ta) #canvas for time_analysis
        self.canvas_ta.setParent(self.frame_ta)
        self.canvas_ta.setFocusPolicy(Qt.StrongFocus)
        self.canvas_ta.setFocus()

        self.mpl_toolbar_ta = NavigationToolbar(self.canvas_ta, self.frame_ta)
        vbox_ta = QtGui.QVBoxLayout()
        vbox_ta.addWidget(self.canvas_ta)
        vbox_ta.addWidget(self.mpl_toolbar_ta)
        self.frame_ta.setLayout(vbox_ta)


        # setup the plot area space for the data generator
        self.frame_gd = self.wgPlotGeneratedData #frame for generating data on
        self.fig_gd = Figure() #Figure((5.0, 4.0), dpi=100)
        self.canvas_gd = FigureCanvas(self.fig_gd)
        self.canvas_gd.setParent(self.frame_gd)
        self.canvas_gd.setFocusPolicy(Qt.StrongFocus)
        self.canvas_gd.setFocus()

        self.mpl_toolbar_gd = NavigationToolbar(self.canvas_gd, self.frame_gd)
        vbox_gd = QtGui.QVBoxLayout()
        vbox_gd.addWidget(self.canvas_gd)
        vbox_gd.addWidget(self.mpl_toolbar_gd)
        self.frame_gd.setLayout(vbox_gd)

    def initial_plot_setup(self):
        #################### setup the initial plots ####################

        self.flows_transmission_time_updated = 0

        self.data = np.zeros( (self.size_x, self.size_y) ) #for initialization only

        self.data1 = np.zeros( (self.size_x, self.size_y) ) #the correspondent data of each subplot
        self.data2 = np.zeros( (self.size_x, self.size_y) )
        self.data3 = np.zeros( (self.size_x, self.size_y) )
        self.data4 = np.zeros( (self.size_x, self.size_y) )

        self.data1 = self.input_data[0]
        self.data2[50,50] = 5

        self.max = np.max(self.data1)
        self.mean = self.max / 2
        self.data3 = np.ones( (self.size_x, self.size_y) ) * self.mean
        self.data3[50,50] = self.max
        self.data3[51,51] = 0

        self.data[50, 50] = 100 # this helps to set the plot ranges, which are automaticaly set at the first plot.
        #TODO: replace it to 'set range' functions instead

        self.fig_ta.clear()
        ### 1
        self.ax1 = self.fig_ta.add_subplot(2,2,1)
        self.ax1.axes.get_xaxis().set_visible(False)
        self.ax1.axes.get_yaxis().set_visible(True)
        self.ax1.set_title('Input Data')
        self.img1 = self.ax1.imshow(self.data1)
        # self.img1 = plt.imshow(self.data1)

        ### 2
        self.ax2 = self.fig_ta.add_subplot(2,2,2)
        self.ax2.axes.get_xaxis().set_visible(False)
        self.ax2.axes.get_yaxis().set_visible(False)
        self.ax2.set_title('Events Detected')
        self.img2 = self.ax2.imshow(self.data2)
        # self.img2 = plt.imshow(self.data2)

        ## 3
        self.ax3 = self.fig_ta.add_subplot(2,2,3)
        self.ax3.axes.get_xaxis().set_visible(True)
        self.ax3.axes.get_yaxis().set_visible(True)
        self.ax3.set_title('Reconstructed Data')
        self.img3 = self.ax3.imshow(self.data3)
        # self.img3 = plt.imshow(self.data3)

        ## 4
        self.ax4 = self.fig_ta.add_subplot(2,2,4)
        self.ax4.axes.get_xaxis().set_visible(True)
        self.ax4.axes.get_yaxis().set_visible(False)
        self.ax4.set_title('Transmission Done')
        self.img4 = self.ax4.imshow(self.data)
        # self.img44 = plt.imshow(self.data)


        self.canvas_ta.draw()

    def read_files(self):
        ###############################################
        # Addresses

        dir = "/home/joao/usn-data/out/"
        video_ext = ".mp4"
        text_ext = ".csv"

        #fn - file name
        fn_pck_trace = dir + "packets-trace" + text_ext
        fn_pck_trace_sink = dir + "packets-sink-trace" + text_ext
        fn_data_input = dir + "../in/input-data" + text_ext

        output_filename = dir + "usn-time-simulation" + video_ext
        ###############################################
        # Var Init

        self.size_x = 101
        self.size_y = 101
        self.sink_x = 50
        self.sink_y = 50
        self.max_packets = 100

        t_unit = int(1E9) #nano seconds

        self.t_initial = int(2 * t_unit)
        self.t_final = int(10 * t_unit) # in seconds ??
        self.t_step = int(.005 * t_unit)
        self.t_simulation_start = 3 * t_unit
        self.t_time_window = .5 * t_unit

        self.times = np.arange(self.t_initial, self.t_final, self.t_step)
        self.t_plot = 0

        self.input_data = []
        self.input_data_time = []
        self.flows_known = []
        self.flows_transmission_time = []
        input_data_single_frame = []
        ################################################


        #################### Reading the trace and data files ###################
        #read from the 3 files:

        #1st - Packets Trace
        self.pck_trace = np.array(list(csv.reader(open(fn_pck_trace, "rb"), delimiter=',')))
        #2nd - Sink Packets Trace
        self.pck_trace_sink = np.array(list(csv.reader(open(fn_pck_trace_sink, "rb"), delimiter=',')))


        #3rd - Input data
        i=0
        j=0
        k=0

        for line in open(fn_data_input):
            if line.startswith('@'):
                j += 1
                # i = 0
                self.input_data_time.append(int(line.replace('@', '')))
                self.input_data.append(zip(*np.array(input_data_single_frame)))
                input_data_single_frame = []
            else:
                input_data_single_frame.append(np.array(line.strip().split(',')).astype('int'))

    def pbSelectWorkingDir_clicked(self):
        dir = QFileDialog.getExistingDirectory(self, ("Open Directory"),
                                             self.tbWorkingDir.text(),
                                             QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks);
        self.tbWorkingDir.setText(dir)

    def pbSelectNs3Dir_clicked(self):
        dir = QFileDialog.getExistingDirectory(self, ("Open Directory"),
                                             self.tbNs3Dir.text(),
                                             QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks);
        self.tbNs3Dir.setText(dir)

    def pbRunSimulation_clicked(self):
        cmd_run = "waf"
        cmd_run_args = "--run 'src/usn/examples/usn-example'"


        process = Popen(['./waf', '--run', '"src/usn/examples/usn-example"'], cwd=self.tbNs3Dir.text(), stdout=PIPE)
        # process = Popen(shlex.split(cmd_cd), stdout=PIPE)
        (output, err) = process.communicate()
        exit_code = process.wait()


        self.teCommand.setText(output)

    def pbGenerate_clicked(self):
        file_name_id = "input-data"
        file_name_cf = "input-config"
        file_extension = ".csv"

        # Read the user input data.
        number_of_sinks = self.sbNumberofSinks.value()
        neighborhood_size = self.sbNeighborhoodSize.value()
        baudrate = self.sbBaudrate.value()
        self.network_size_x = self.sbNetworkSizeX.value()
        self.network_size_y = self.sbNetworkSizeY.value()
        number_of_cycles = self.sbNumbeofCycles.value()
        period = self.sbPeriod.value() * 1E6 # from milis to nano seconds
        self.sensor_resolution = self.sbSensorResolution.value()
        output_dir = self.tbWorkingDir.text()
        self.sensor_scale = pow(2, self.sensor_resolution);

        # Setup the initial plot
        self.input_data_generated = np.ones( (self.network_size_x, self.network_size_y) )
        self.input_data_generated[int(self.network_size_x)/2][int(self.network_size_y)/2] = self.sensor_scale
        self.axg = self.fig_gd.add_subplot(1,1,1)
        self.axg.axes.get_xaxis().set_visible(True)
        self.axg.axes.get_yaxis().set_visible(True)
        self.axg.set_title('Input Sensors Data')
        self.imgg = self.axg.imshow(self.input_data_generated)

        def f(x, y):
            return ( np.sin(x) * np.cos(y) ) * self.sensor_scale / 2 + self.sensor_scale / 2; #offset to between 0 and max

        x = np.linspace(0, 2 * np.pi, self.network_size_x)
        y = np.linspace(0, 2 * np.pi, self.network_size_y).reshape(-1, 1)


        self.input_data_list = []

        with file(output_dir + '/in/' + file_name_id + file_extension, 'w') as output_data:
            i = 0
            for i in range(number_of_cycles):
                x += np.pi / 30. ## the steps in x and y
                y += np.pi / 30.

                self.input_data_generated = f(x, y)
                self.input_data_list.append(self.input_data_generated)
                # self.imgg.set_array(self.input_data_generated)
                # self.canvas_generate_data.draw()



                savetxt(output_data, self.input_data_generated, delimiter=',' , fmt='%d')
                # metadata goes at after the data, as it is easier to read
                output_data.write('@' + str(i * int(period)) + '\n') # starts with # and ends at @
                # print(np.max(d))
                # print(np.min(d))

                i += 1



        self.imgg.set_array(self.input_data_list[0])
        self.canvas_gd.draw()
        self.ig = 1
        self.timer_gd.start(200)


    def pbStart_clicked(self):
        # self.lbTime.setText("Teste")
        # plots the data with animation
        # ani = animation.FuncAnimation(self.fig, self.animate, np.arange(self.t_initial, self.t_final, self.t_step), interval=15, blit=True, repeat=False)
        self.t_plot = 0
        self.read_files()
        self.initial_plot_setup()
        self.timer_ta.start(500)

    def pbStop_clicked(self):
        self.timer_ta.stop()
        self.t_plot = 0

    def update_plot(self):
        # while i < times.size:

        if self.t_plot < self.times.size - 1:
            self.t_plot += 1
            self.animate_ta(self.times[self.t_plot])
            self.lbTime.setText("t = " + str(self.times[self.t_plot] * 1E-6) + " ms")

            if self.flows_transmission_time_updated == 1:
                self.flows_transmission_time_updated = 0
                self.tableWidget.setRowCount(len(self.flows_transmission_time))
                cc = 0
                for l in self.flows_transmission_time:
                    x = np.abs(l[3])
                    y = np.abs(l[4])
                    if x >= self.sink_x: # calculates the distance
                        dx = x - self.sink_x
                    else:
                        dx = self.sink_x - x
                    if y >= self.sink_y:
                        dy = y - self.sink_y
                    else:
                        dy = self.sink_y - y

                    dist =  dx + dy
                    # self.listWidget.addItem(str(l[0]) + '\t(' + str(l[3]) + ',' + str(l[4]) + ') d=' + str(dist) + '\t' + str( (l[2] - l[1]) * 10E-6))
                    self.tableWidget.setItem(cc,0,QTableWidgetItem(str(l[0])))
                    self.tableWidget.setItem(cc,1,QTableWidgetItem('(' + str(l[4]) + ',' + str(l[3]) + ') d=' + str(dist)))
                    self.tableWidget.setItem(cc,2,QTableWidgetItem(str((l[2] - l[1]) * 1E-6)))
                    self.tableWidget.setItem(cc,3,QTableWidgetItem(str(l[5] * 1E-6)))
                    cc+=1

        else:
            self.timer_ta.stop()

    ################## function called to animate the plots ########
    def animate_ta(self, t):
        # global data1, data2, data3, data4
        global i,j, k

        ## traces for all the packets
        pck_trace_line = self.pck_trace[i]
        t_instant = int(pck_trace_line[1])
        flow_id = int(pck_trace_line[2])
        cord_x = int(pck_trace_line[4])
        cord_y = int(pck_trace_line[5])

        ## trances for the sink only
        pck_trace_line_sink = self.pck_trace_sink[k]
        t_instant_sink = int(pck_trace_line_sink[1])
        flow_id_sink = int(pck_trace_line_sink[2])
        protocol_number_sink = int(pck_trace_line_sink[7])
        pck_value = int(pck_trace_line_sink[11])
        cord_x_sink = int(pck_trace_line_sink[12])
        cord_y_sink = int(pck_trace_line_sink[13])


        # in this loop, it will process all the data that have occurred until the current time instant t
        # for all of the data logs. Input data will change, also all the packets transmitted/received until that
        while t_instant < t:

            if flow_id not in self.flows_known:
                self.flows_known.append(flow_id)
                self.flows_transmission_time.append([flow_id, t_instant, t_instant, cord_x, cord_y, 0]) #flow start time, end time, x_cord_origin, y_cord_origin, t_queing_delay
                self.data2[cord_x, cord_y] += 1
            else: #here I log the start and end of a flow.
                for m, f in enumerate(self.flows_transmission_time): # f gets the line element, and m the iterator counter (i)
                    if flow_id == f[0]:
                        if t_instant > f[2]:
                            if t_instant - f[2] > f[5]: # get the maximum queueing delay
                                self.flows_transmission_time[m][5] = t_instant - f[2]
                            self.flows_transmission_time[m][2] = t_instant
                            self.flows_transmission_time_updated = 1


            self.data4[cord_x, cord_y] += 1

            #get data from the next time instant to check if it has occurred already or not
            i = i+1
            pck_trace_line = self.pck_trace[i]
            t_instant = int(pck_trace_line[1])
            flow_id = int(pck_trace_line[2])
            cord_x = int(pck_trace_line[4])
            cord_y = int(pck_trace_line[5])

            # plot the input data moving along the time
            if t_instant > self.input_data_time[j] + self.t_simulation_start:
                j += 1
                self.data1 = self.input_data[j]

            # plot the data reconstruction along the time
            if t_instant_sink < t_instant:
                k += 1
                x = self.size_x - np.floor(cord_x_sink + self.size_x / 2) - 1
                y = self.size_y - np.floor(cord_y_sink + self.size_y / 2) - 1
                self.data3[x, y] = pck_value

                if k > 1:
                    pck_trace_line_sink_previous = self.pck_trace_sink[k-2]
                    t_instant_sink_previous = int(pck_trace_line_sink_previous[1])
                else:
                    t_instant_sink_previous = t_instant_sink

                if t_instant_sink - t_instant_sink_previous > self.t_time_window:
                    self.data3 = np.ones( (self.size_x, self.size_y) ) * self.mean # reset the values know by the sink if they are too old

                pck_trace_line_sink = self.pck_trace_sink[k]
                t_instant_sink = int(pck_trace_line_sink[1])
                flow_id_sink = int(pck_trace_line_sink[2])
                pck_value = int(pck_trace_line_sink[11])
                cord_x_sink = int(pck_trace_line_sink[12])
                cord_y_sink = int(pck_trace_line_sink[13])


        # transfer the new data to its respective subplot
        self.img1.set_array(self.data1)
        self.img2.set_array(self.data2)
        self.img3.set_array(self.data3)
        self.img4.set_array(self.data4)

        self.canvas_ta.draw()
        # self.draw()

        return self.img1, self.img2, self.img3, self.img4


    def animate_gd(self):
        self.imgg.set_array(self.input_data_list[self.ig])
        self.canvas_gd.draw()
        self.ig += 1
        if self.ig == len(self.input_data_list):
            # self.timer_gd.stop()
            self.ig = 0



app = QtGui.QApplication(sys.argv)
myWindow = MyWindowClass(None)
myWindow.show()
app.exec_()
# print "end"



#
#
#
# i=0
# j=0
# k=0
# ################################################################
#

#
#



